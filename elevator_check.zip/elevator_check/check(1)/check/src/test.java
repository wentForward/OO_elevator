import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class test {
    public static void main(String[] args) {
        String space = "[ ]*";
        String timecheck = "max"+space+"time"+space+"is"+space+"(?<maxtime>\\d+)";
        Pattern pattern = Pattern.compile(timecheck);
        Matcher m = pattern.matcher("Check Pass!     Your input is valid, base time is 56, max time is 60");
        System.out.println(m.find());
    }
}
