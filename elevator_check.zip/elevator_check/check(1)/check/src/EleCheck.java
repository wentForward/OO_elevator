import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EleCheck {
    private ArrayList<String> datalist = new ArrayList<String>();
    private ArrayList<String> inputlist = new ArrayList<String>();
    private HashMap<String, Person> PersonMap = new HashMap<String, Person>();
    private String time;

    public EleCheck(ArrayList<String> datalist, ArrayList<String> inputlist) {
        this.datalist = datalist;
        this.inputlist = inputlist;
    }

    public void SetData() {
        Iterator<String> it = datalist.iterator();
        while (it.hasNext()) {
            String infor = it.next();
            String parseinfor = "\\[.+\\](?<id>\\d+)-FROM-(?<from>\\d+)-TO-(?<to>\\d+)";
            Pattern pattern = Pattern.compile(parseinfor);
            Matcher m = pattern.matcher(infor);
            if (m.matches()) {
                String id = m.group("id");
                String fromfloor = m.group("from");
                String tofloor = m.group("to");
                Person person = new Person(id, fromfloor, tofloor);
                PersonMap.put(id, person);
            }
        }
    }

    public void SetInOut() {
        Iterator<String> it = inputlist.iterator();
        final Double diff = 1e-35;
        Double arrivetime = -1.0;
        Double opentime = -1.0;
        Double closetime = -1.0;
        while (it.hasNext()) {
            String infor = it.next();
            String parseinout = "\\[(?<time>.+)\\]((?<in>IN-)||(?<out>OUT-))(?<id>\\d+)-(?<floor>\\d+)";
            String gettime = "\\[(?<time1>.+)\\]";
            String arrive = "\\[(?<arrivetime>.+)\\](ARRIVE-(\\d+))";
            String open = "\\[(?<opentime>.+)\\](open-(\\d+))";
            String close = "\\[(?<closetime>.+)\\](CLOSE-(\\d+))";
            Pattern pattern = Pattern.compile(parseinout);
            Matcher m = pattern.matcher(infor);
            if (m.matches()) {
                String id = m.group("id");
                String floor = m.group("floor");
                Person person = PersonMap.get(id);
                if (m.group("in") != null) {
                    if(person.getFrom().equals(floor)){
                        if(person.getFromtime()==null){
                            person.setFromtime(m.group("time"));
                        }else{
                            System.out.println("PERSON "+id+" GET IN TO THE ELE MORE THAN ONE TIME!");
                            System.exit(-15);
                        }
                    }else{
                        System.out.println("PERSON GET IN IN A WRONG FLOOR");
                        System.exit(-15);
                    }
                } else if (m.group("out") != null) {
                    if(person.getTo().equals(floor)){
                        if(person.getTotime()==null){
                            person.setTotime(m.group("time"));
                        }else{
                            System.out.println("PERSON "+id+" GET OUT OF THE ELE MORE THAN ONE TIME!");
                            System.exit(-15);
                        }
                    }else{
                        System.out.println("PERSON GET OFF IN A WRONG FLOOR");
                        System.exit(-15);
                    }
                }
            }
            Pattern pattern1 = Pattern.compile(gettime);
            Matcher m1 = pattern1.matcher(infor);
            if(m1.find()){
                time = m1.group("time1");
            }

            //arrive time judge
            Pattern pattern2 = Pattern.compile(arrive);
            Matcher m2 = pattern2.matcher(infor);
            if(m2.find()){
                Double thisarrive = Double.parseDouble(m2.group("arrivetime"));
                if(arrivetime==-1.0){//first arrive
                    arrivetime = thisarrive;
                }else{
                    if(thisarrive-arrivetime<0.39999999){
                        System.out.println("ARRIVE TIME ERROR!(LESS THAN 0.4S)");
                        System.exit(-16);
                    }
                    arrivetime = thisarrive;
                }
            }

            // open/close time judge
            Pattern pattern3 = Pattern.compile(open);
            Matcher m3 = pattern3.matcher(infor);
            if(m3.find()){
                opentime = Double.parseDouble(m3.group("opentime"));
            }
            Pattern pattern4 = Pattern.compile(close);
            Matcher m4 = pattern4.matcher(infor);
            if(m4.find()){
                closetime = Double.parseDouble(m4.group("closetime"));
                if(closetime-opentime<0.39999999){
                    System.out.println("OPEN&CLOSE TIME ERROR!(LESS THAN 0.4S)");
                    System.exit(-16);
                }
            }

        }
    }

    public String getTime() {
        return time;
    }

    public void Check() {
        Iterator it = PersonMap.keySet().iterator();
        while (it.hasNext()) {
            String id = (String) it.next();
            Person person = PersonMap.get(id);
            String intime = person.getFromtime();
            String outtime = person.getTotime();
            Double in = 0.0;
            Double out = 0.0;
            if(intime!=null&&outtime!=null){
                in = Double.parseDouble(intime);
                out = Double.parseDouble(outtime);
            }
            if(intime!=null&&outtime!=null&&(in<out)){

            }else{
                if(intime==null){
                    System.out.println("PERSON NOT IN TO ELE");
                    System.exit(-10);
                } else if(outtime==null){
                    System.out.println("PERSON NOT OUT OF ELE");
                    System.exit(-11);
                } else if(in>=out){
                    System.out.println("PERSON OUT BEFORE IN");
                    System.exit(-12);
                }
            }
        }
    }
}
