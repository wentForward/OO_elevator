import java.io.File;
import java.io.FileNotFoundException;
import java.lang.annotation.ElementType;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Scanner dataput = null;
        Scanner input = null;
        Scanner timeput = null;
        try {
            dataput = new Scanner(new File("Data.txt"));
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
        }

        ArrayList datalist = new ArrayList();
        while(dataput.hasNextLine()) {
            String temp = dataput.nextLine().replaceAll("OPEN", "open");
            datalist.add(temp);
        }

        try {
            timeput = new Scanner(new File("timecheck.txt"));
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
        }

        String timeline = "";
        while(timeput.hasNextLine()) {
            timeline = timeput.nextLine();
        }


        try {
            input = new Scanner(new File("myRe.txt"));
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
        }

        ArrayList inputlist = new ArrayList();

        while(input.hasNextLine()) {
            String temp = input.nextLine().replaceAll("OPEN", "open");
            inputlist.add(temp);
        }

        Check elevatorCheck = new Check(inputlist);
        elevatorCheck.BehaviorCheck();
        EleCheck eleCheck = new EleCheck(datalist,inputlist);
        eleCheck.SetData();
        eleCheck.SetInOut();
        eleCheck.Check();
        String yourtime = eleCheck.getTime();
        yourtime = yourtime.replaceAll("[ ]+","");
        TimeCheck timeCheck = new TimeCheck();
        timeCheck.CheckTime(timeline,yourtime);
        //System.out.println(time);
        System.out.println("ACCEPTED!");
    }
}
