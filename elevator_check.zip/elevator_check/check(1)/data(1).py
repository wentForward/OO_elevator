# creatData.py
import math
import random
start = 0
end = 3
a=0.0
i=0
while(i<20): 
    randnum = round(random.uniform(start,end),1)
    fromfloor = random.randint(1,15)
    tofloor = random.randint(1,15)
    while(tofloor==fromfloor):
        tofloor =random.randint(1,15)
    print(("["+str(round(a,1))+"]"+str(i)+"-FROM-"+str(fromfloor)+"-TO-"+str(tofloor)))
    i=i+1
    a=a+randnum
