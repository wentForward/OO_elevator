package check;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TimeCheck {

    public TimeCheck() {

    }

    public void CheckTime(String timeput,String yourtime){
        String space = "[ ]+";
        String timecheck = "max"+space+"time"+space+"is"+space+"(?<maxtime>\\d+)";
        Pattern pattern = Pattern.compile(timecheck);
        Matcher m2 = pattern.matcher(timeput);
        if(m2.find()){
            Double maxtime = Double.parseDouble(m2.group("maxtime"));
            Double time = Double.parseDouble(yourtime);
            if(time>maxtime){
                System.out.println("TIME EXCEED ERROR: MAXTIME IS "+maxtime+" YOUR TIME IS "+time);
                System.exit(-9);
            }
        }
    }
}
