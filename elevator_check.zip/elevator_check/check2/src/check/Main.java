package check;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.annotation.ElementType;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Scanner dataput = null;
        Scanner input = null;
        Scanner timeput = null;
        try {
            dataput = new Scanner(new File("Data.txt"));
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
        }

        ArrayList datalist = new ArrayList();
        String numstr = dataput.nextLine();
        Pattern p = Pattern.compile("\\[.+\\](?<num>\\d+)");
        Matcher m = p.matcher(numstr);
        if(m.matches()){
            int elenum = Integer.parseInt(m.group("num"));
        }
        while(dataput.hasNextLine()) {
            String temp = dataput.nextLine().replaceAll("OPEN", "open");
            datalist.add(temp);
        }

        try {
            timeput = new Scanner(new File("timecheck.txt"));
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
        }

        String timeline = "";
        while(timeput.hasNextLine()) {
            timeline = timeput.nextLine();
        }


        try {
            input = new Scanner(new File("myRe.txt"));
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
        }

        ArrayList inputlist = new ArrayList();

        while(input.hasNextLine()) {
            String temp = input.nextLine().replaceAll("OPEN", "open");
            inputlist.add(temp);
        }

        CheckAll(inputlist);
        EleCheck eleCheck = new EleCheck(datalist,inputlist);
        eleCheck.SetData();
        eleCheck.SetInOut();
        eleCheck.Check();
        String yourtime = eleCheck.getTime();
        yourtime = yourtime.replaceAll("[ ]+","");
        TimeCheck timeCheck = new TimeCheck();
        timeCheck.CheckTime(timeline,yourtime);
        System.out.println(yourtime);
        System.out.println("ACCEPTED!");
        /*ArrayList inputlist = new ArrayList();
        Scanner input = new Scanner(System.in);
        while(input.hasNextLine()) {
            String temp = input.nextLine().replaceAll("OPEN", "open");
            inputlist.add(temp);
        }
        CheckAll(inputlist);*/
    }

    public static void CheckAll(ArrayList<String> inputlist) {
        ArrayList<String> listA = new ArrayList<>();
        ArrayList<String> listB = new ArrayList<>();
        ArrayList<String> listC = new ArrayList<>();
        ArrayList<String> listD = new ArrayList<>();
        ArrayList<String> listE = new ArrayList<>();
        for (String str: inputlist
        ) {
            switch (str.charAt(str.length() - 1)) {
                case 'A':
                    str = str.substring(0,str.length() - 2);
                    listA.add(str);
                    break;
                case 'B':
                    str = str.substring(0,str.length() - 2);
                    listB.add(str);
                    break;
                case 'C':
                    str = str.substring(0,str.length() - 2);
                    listC.add(str);
                    break;
                case 'D':
                    str = str.substring(0,str.length() - 2);
                    listD.add(str);
                    break;
                case 'E':
                    str = str.substring(0,str.length() - 2);
                    listE.add(str);
                    break;
                default: ;
            }
        }
        if (listA.size() != 0) {
            Check Acheck = new Check(listA);
            Acheck.BehaviorCheck("A");
        }
        if (listB.size() != 0) {
            Check Bcheck = new Check(listB);
            Bcheck.BehaviorCheck("B");
        }
        if (listC.size() != 0) {
            Check Ccheck = new Check(listC);
            Ccheck.BehaviorCheck("C");
        }
        if (listD.size() != 0) {
            Check Dcheck = new Check(listD);
            Dcheck.BehaviorCheck("D");
        }
        if (listE.size() != 0) {
            Check Echeck = new Check(listE);
            Echeck.BehaviorCheck("E");
        }
    }
}
