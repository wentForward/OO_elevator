package check;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class EleCheck {
    private ArrayList<String> datalist = new ArrayList<String>();
    private ArrayList<String> inputlist = new ArrayList<String>();
    private HashMap<String,Double> arrivetime = new HashMap<String,Double>();
    private HashMap<String,Double> opentime = new HashMap<String,Double>();
    private HashMap<String, Person> PersonMap = new HashMap<String, Person>();
    private HashMap<String,Elevator> eleMap = new HashMap<String,Elevator>();
    private String time;

    public EleCheck(ArrayList<String> datalist, ArrayList<String> inputlist) {
        this.datalist = datalist;
        this.inputlist = inputlist;
    }

    public void SetData() {
        Iterator<String> it = datalist.iterator();
        while (it.hasNext()) {
            String infor = it.next();
            String parseinfor = "\\[.+\\](?<id>\\d+)-FROM-(?<sign1>-?)(?<from>\\d+)-TO-(?<sign>-?)(?<to>\\d+)";
            Pattern pattern = Pattern.compile(parseinfor);
            Matcher m = pattern.matcher(infor);
            if (m.matches()) {
                String id = m.group("id");
                String fromfloor = m.group("from");
                if(m.group("sign1")!=null){
                    fromfloor = "-"+fromfloor;
                }
                String tofloor = m.group("to");
                if(m.group("sign")!=null){
                    tofloor = "-"+tofloor;
                }
                Person person = new Person(id, fromfloor, tofloor);
                PersonMap.put(id, person);
            }
        }
    }

    public void SetInOut() {
        Iterator<String> it = inputlist.iterator();
        final Double diff = 1e-35;
        Elevator eleA = new Elevator("A");
        Elevator eleB = new Elevator("B");
        Elevator eleC = new Elevator("C");
        Elevator eleD = new Elevator("D");
        Elevator eleE = new Elevator("E");
        eleMap.put("A",eleA);
        eleMap.put("B",eleB);
        eleMap.put("C",eleC);
        eleMap.put("D",eleD);
        eleMap.put("E",eleE);
        while (it.hasNext()) {
            String infor = it.next();
            String parseinout = "\\[(?<time>.+)\\]((?<in>IN-)||(?<out>OUT-))(?<id>\\d+)-(?<sign>-?)(?<floor>\\d+)-(?<elename>.+)";
            String gettime = "\\[(?<time1>.+)\\]";
            String arrive = "\\[(?<arrivetime>.+)\\](ARRIVE-(?<sign>-?)(\\d+)-(?<elename>.+))";
            String open = "\\[(?<opentime>.+)\\](open-(?<sign>-?)(\\d+)-(?<elename>.+))";
            String close = "\\[(?<closetime>.+)\\](CLOSE-(?<sign>-?)(\\d+)-(?<elename>.+))";
            Pattern pattern = Pattern.compile(parseinout);
            Matcher m = pattern.matcher(infor);
            if (m.matches()) {
                String id = m.group("id");
                String floor = m.group("floor");
                if(m.group("sign")!=null){
                    floor = "-"+floor;
                }
                String elename = m.group("elename");
                Person person = PersonMap.get(id);
                if (m.group("in") != null) {
                    if(person.getFrom().equals(floor)){
                        if(person.getFromtime()==null&&person.getElename()==null){
                            person.setFromtime(m.group("time"));
                            person.setElename(elename);
                            Elevator ele = eleMap.get(elename);
                            if(ele.getPassagernum()==7){
                                System.out.println("ELE OVERLOAD!");
                                System.exit(-30);
                            }
                            ele.setPassagernum(ele.getPassagernum()+1);
                            eleMap.put(elename,ele);
                        }else{
                            System.out.println("PERSON "+id+" GET IN TO THE ELE MORE THAN ONE TIME!");
                            System.exit(-15);
                        }
                    }else{
                        System.out.println("PERSON GET IN IN A WRONG FLOOR");
                        System.exit(-15);
                    }
                } else if (m.group("out") != null) {
                    if(person.getTo().equals(floor)){
                        if(person.getTotime()==null){
                            person.setTotime(m.group("time"));
                        }else{
                            System.out.println("PERSON "+id+" GET OUT OF THE ELE MORE THAN ONE TIME!");
                            System.exit(-15);
                        }
                        if(!person.getElename().equals(elename)){
                            System.out.println("PERSON "+id+" OUT IN DIFFERENT ELE!");
                        }else{
                            Elevator ele = eleMap.get(elename);
                            ele.setPassagernum(ele.getPassagernum()-1);
                            eleMap.put(elename,ele);
                        }
                    }else{
                        System.out.println("PERSON GET OFF IN A WRONG FLOOR");
                        System.exit(-15);
                    }
                }
            }
            Pattern pattern1 = Pattern.compile(gettime);
            Matcher m1 = pattern1.matcher(infor);
            if(m1.find()){
                time = m1.group("time1");
            }

            //arrive time judge
            Pattern pattern2 = Pattern.compile(arrive);
            Matcher m2 = pattern2.matcher(infor);
            if(m2.find()){
                Double thisarrive = Double.parseDouble(m2.group("arrivetime"));
                String elename = m2.group("elename");
                if(arrivetime.get(elename)==null){
                    arrivetime.put(elename,thisarrive);
                }else{
                    Double lastarrive = arrivetime.get(elename);
                    if(thisarrive-lastarrive<0.39999999){
                        System.out.println("ARRIVE TIME ERROR!(LESS THAN 0.4S)");
                        System.exit(-16);
                    }
                    arrivetime.put(elename,thisarrive);
                }
            }

            // open/close time judge
            Pattern pattern3 = Pattern.compile(open);
            Matcher m3 = pattern3.matcher(infor);
            Double thisopen = -1.0;
            if(m3.find()){
                thisopen = Double.parseDouble(m3.group("opentime"));
                String elename = m3.group("elename");
                opentime.put(elename,thisopen);
            }
            Pattern pattern4 = Pattern.compile(close);
            Matcher m4 = pattern4.matcher(infor);
            Double thisclose = -1.0;
            if(m4.find()){
                thisclose = Double.parseDouble(m4.group("closetime"));
                String elename = m4.group("elename");
                Double lastopen = opentime.get(elename);
                if(thisclose-lastopen<0.39999999){
                    System.out.println("OPEN&CLOSE TIME ERROR!(LESS THAN 0.4S)");
                    System.exit(-16);
                }
            }

        }
    }

    public String getTime() {
        return time;
    }

    public void Check() {
        Iterator it = PersonMap.keySet().iterator();
        while (it.hasNext()) {
            String id = (String) it.next();
            Person person = PersonMap.get(id);
            String intime = person.getFromtime();
            String outtime = person.getTotime();
            Double in = 0.0;
            Double out = 0.0;
            if(intime!=null&&outtime!=null){
                in = Double.parseDouble(intime);
                out = Double.parseDouble(outtime);
            }
            if(intime!=null&&outtime!=null&&(in<out)){

            }else{
                if(intime==null){
                    System.out.println("PERSON NOT IN TO ELE");
                    System.exit(-10);
                } else if(outtime==null){
                    System.out.println("PERSON NOT OUT OF ELE");
                    System.exit(-11);
                } else if(in>=out){
                    System.out.println("PERSON OUT BEFORE IN");
                    System.exit(-12);
                }
            }
        }
    }
}
