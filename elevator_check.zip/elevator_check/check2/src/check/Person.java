package check;

public class Person {
    private String id;
    private String from;
    private String to;
    private String fromtime=null;
    private String totime=null;
    private String elename = null;

    public Person(String id,String from,String to){
        this.id = id;
        this.from = from;
        this.to = to;
    }

    public void setFromtime(String from){
        fromtime = from;
    }
    public  void setTotime(String to){
        totime = to;
    }

    public String getFromtime() {
        return fromtime;
    }

    public String getTotime() {
        return totime;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getElename() {
        return elename;
    }

    public void setElename(String elename) {
        this.elename = elename;
    }
}
