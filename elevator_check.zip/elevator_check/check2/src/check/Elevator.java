package check;

public class Elevator {
    private String elename = "";
    private int passagernum = 0;

    public Elevator(String elename){
        this.elename = elename;
    }

    public int getPassagernum() {
        return passagernum;
    }

    public void setPassagernum(int passagernum) {
        this.passagernum = passagernum;
    }

    public String getElename() {
        return elename;
    }
}
