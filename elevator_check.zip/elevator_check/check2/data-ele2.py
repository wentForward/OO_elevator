# creatData.py
import math
import random
start = 0
end = 3
a=0.0
i=0
flag = 0
num = random.randint(1,5)
while(i<35): 
    randnum = round(random.uniform(start,end),1)
    if(flag==0):
        print("["+str(round(a,1))+"]"+str(num))
        flag=1
    else:
        fromfloor = random.randint(-3,16)
        tofloor = random.randint(-3,16)
        while(fromfloor==0):
	        fromfloor = random.randint(-3,16)
        while((tofloor==fromfloor)or(tofloor==0)):
            tofloor =random.randint(-3,16)
        print(("["+str(round(a,1))+"]"+str(i)+"-FROM-"+str(fromfloor)+"-TO-"+str(tofloor)))
    i=i+1
    a=a+randnum
