# creatData.py
import math
import random
start = 0
end = 2
a=0.0
i=0
flag = 0
num = random.randint(1,29)
num1 = random.randint(1,29)
while(num1==num):
    num1 = random.randint(1,29)
s  = random.randint(65,67)
eletype = chr(s)
s  = random.randint(65,67)
eletype1 = chr(s)
#print("["+str(round(a,1))+"]"+str(num))
a=2.0
while(i<30): 
    randnum = round(random.uniform(start,end),1)
    if(i==num):
        print("["+str(round(a,1))+"]"+"X1-ADD-ELEVATOR-"+eletype)
    elif(i==num1):
        print("["+str(round(a,1))+"]"+"X2-ADD-ELEVATOR-"+eletype1)
    else:
        fromfloor = random.randint(-3,20)
        tofloor = random.randint(-3,20)
        while(fromfloor==0):
            fromfloor = random.randint(-3,20)
        while((tofloor==fromfloor)or(tofloor==0)):
            tofloor =random.randint(-3,20)
        print(("["+str(round(a,1))+"]"+str(i)+"-FROM-"+str(fromfloor)+"-TO-"+str(tofloor)))
    i=i+1
    a=a+randnum
