package check3;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.annotation.ElementType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Scanner dataput = null;
        Scanner input = null;
        Scanner timeput = null;
        try {
            dataput = new Scanner(new File("Data.txt"));
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
        }

        ArrayList datalist = new ArrayList();
        while(dataput.hasNextLine()) {
            String temp = dataput.nextLine().replaceAll("OPEN", "open");
            datalist.add(temp);
        }

        try {
            timeput = new Scanner(new File("timecheck.txt"));
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
        }

        String timeline = "";
        while(timeput.hasNextLine()) {
            timeline = timeput.nextLine();
        }


        try {
            input = new Scanner(new File("myRe.txt"));
        } catch (FileNotFoundException var4) {
            var4.printStackTrace();
        }

        ArrayList inputlist = new ArrayList();

        while(input.hasNextLine()) {
            String temp = input.nextLine().replaceAll("OPEN", "open");
            inputlist.add(temp);
        }

        EleCheck eleCheck = new EleCheck(datalist,inputlist);
        CheckAll(inputlist, eleCheck.getEleMap());
        eleCheck.SetData();
        eleCheck.SetInOut();
        eleCheck.Check();
        String yourtime = eleCheck.getTime();
        yourtime = yourtime.replaceAll("[ ]+","");
        TimeCheck timeCheck = new TimeCheck();
        timeCheck.CheckTime(timeline,yourtime);
        System.out.println(yourtime);
        System.out.println("ACCEPTED!");
    }

    public static void CheckAll(ArrayList<String> inputlist, HashMap<String , Elevator> map) {
        HashMap<String, Elevator> elemap = map;
        HashMap<String , ArrayList<String>> input = new HashMap<>();
        for (String str: inputlist
        ) {
            String getname = ".*-(.*)";
            Pattern name = Pattern.compile(getname);
            Matcher namem = name.matcher(str);
            while (namem.find()) {
                String eleN = namem.group(1);
                if (!input.containsKey(eleN)) {
                    ArrayList<String> inf = new ArrayList<>();
                    inf.add(str.substring(0, str.length() - 1 - eleN.length()));
                    input.put(eleN, inf);
                } else {
                    ArrayList<String> temp = input.get(eleN);
                    temp.add(str.substring(0, str.length() - 1 - eleN.length()));
                    input.put(eleN, temp);
                }
            }
            for (Map.Entry<String, ArrayList<String>> entry : input.entrySet()
            ) {
                String nameortype = entry.getKey();
                switch (nameortype) {
                    case "A":
                        Check Acheck = new Check(entry.getValue());
                        Acheck.BehaviorCheckA("A");
                        break;
                    case "B":
                        Check Bcheck = new Check(entry.getValue());
                        Bcheck.BehaviorCheckB("B");
                        break;
                    case "C":
                        Check Ccheck = new Check(entry.getValue());
                        Ccheck.BehaviorCheckC("C");
                        break;
                    default:
                        String type = "";
                        //请填空：此处通过nameortype变量（该变量为电梯的名字，即xi）得到其对应的电梯类型
                        type = elemap.get(nameortype).getType();
                        if (type.equals("A")) {
                            Check XAcheck = new Check(entry.getValue());
                            XAcheck.BehaviorCheckA(nameortype);
                        } else if (type.equals("B")) {
                            Check XBcheck = new Check(entry.getValue());
                            XBcheck.BehaviorCheckB(nameortype);
                        } else {
                            Check XCcheck = new Check(entry.getValue());
                            XCcheck.BehaviorCheckC(nameortype);
                        }
                }
            }
        }
    }
}
