package check3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class EleCheck {
    private ArrayList<String> datalist = new ArrayList<String>();
    private ArrayList<String> inputlist = new ArrayList<String>();
    private HashMap<String,Double> arrivetime = new HashMap<String,Double>();
    private HashMap<String,Double> opentime = new HashMap<String,Double>();
    private HashMap<String, Person> PersonMap = new HashMap<String, Person>();
    private HashMap<String,Elevator> eleMap = new HashMap<String,Elevator>();
    private String time;

    public EleCheck(ArrayList<String> datalist, ArrayList<String> inputlist) {
        this.datalist = datalist;
        this.inputlist = inputlist;
    }

    public HashMap<String,Elevator> getEleMap() {
        return eleMap;
    }

    public void SetData() {
        Iterator<String> it = datalist.iterator();
        while (it.hasNext()) {
            String infor = it.next();
            String parseinfor = "\\[.+\\](?<id>\\d+)-FROM(?<sign1>-{1,2})(?<from>\\d+)-TO(?<sign>-{1,2})(?<to>\\d+)";
            Pattern pattern = Pattern.compile(parseinfor);
            Matcher m = pattern.matcher(infor);
            String parseele = "\\[.+\\](?<elename>.+)-ADD-ELEVATOR-(?<eletype>.+)";
            Pattern pattern1 = Pattern.compile(parseele);
            Matcher m1 = pattern1.matcher(infor);
            if (m.matches()) {
                String id = m.group("id");
                String fromfloor = m.group("from");
                if(m.group("sign1").equals("--")){
                    fromfloor = "-"+fromfloor;
                }
                String tofloor = m.group("to");
                if(m.group("sign").equals("--")){
                    tofloor = "-"+tofloor;
                }
                Person person = new Person(id, fromfloor, tofloor);
                PersonMap.put(id, person);
            }else if(m1.matches()){
                String type = m1.group("eletype");
                String elename = m1.group("elename");
                Elevator ele = new Elevator(elename,type);
                eleMap.put(elename,ele);
            }
        }
    }

    public void SetInOut() {
        Iterator<String> it = inputlist.iterator();
        final Double diff = 1e-35;
        Elevator eleA = new Elevator("A","A");
        Elevator eleB = new Elevator("B","B");
        Elevator eleC = new Elevator("C","C");
        eleMap.put("A",eleA);
        eleMap.put("B",eleB);
        eleMap.put("C",eleC);
        while (it.hasNext()) {
            String infor = it.next();
            String parseinout = "\\[(?<time>.+)\\]((?<in>IN-)||(?<out>OUT-))(?<id>\\d+)(?<sign>-{1,2})(?<floor>\\d+)-(?<elename>.+)";
            String gettime = "\\[(?<time1>.+)\\]";
            String arrive = "\\[(?<arrivetime>.+)\\](ARRIVE(?<sign>-{1,2})(\\d+)-(?<elename>.+))";
            String open = "\\[(?<opentime>.+)\\](open(?<sign>-{1,2})(\\d+)-(?<elename>.+))";
            String close = "\\[(?<closetime>.+)\\](CLOSE(?<sign>-{1,2})(\\d+)-(?<elename>.+))";
            Pattern pattern = Pattern.compile(parseinout);
            Matcher m = pattern.matcher(infor);
            if (m.matches()) {
                String id = m.group("id");
                String floor = m.group("floor");
                if(m.group("sign").equals("--")){
                    floor = "-"+floor;
                }
                String elename = m.group("elename");
                Person person = PersonMap.get(id);
                if (m.group("in") != null) {
                    //if(person.getFrom().equals(floor)){
                    //System.out.println(id);
                        if(person.getFromtime1()==null&&person.getElename1()==null){
                            person.setFromtime1(m.group("time"));
                            person.setElename1(elename);
                            Elevator ele = eleMap.get(elename);
                            if(ele.getPassagernum()==ele.getCapacity()){
                                System.out.println("ELE OVERLOAD!");
                                System.exit(-30);
                            }
                            ele.setPassagernum(ele.getPassagernum()+1);
                            eleMap.put(elename,ele);
                            if(!person.getFrom().equals(floor)){
                                System.out.println(id+"PERSON GET IN IN A WRONG FLOOR");
                                System.exit(-15);
                            }
                        }else if(person.getFromtime1()!=null&&person.getElename1()!=null&&person.getFromtime2()==null&&person.getMiddlefloor()!=null){
                            if(!person.getMiddlefloor().equals(floor)){
                                System.out.println(id+"PERSON GET IN IN A WRONG FLOOR(SECOND)");
                                System.exit(-15);
                            }else{
                                person.setFromtime2(m.group("time"));
                                person.setElename2(elename);
                                Elevator ele = eleMap.get(elename);
                                if(ele.getPassagernum()==ele.getCapacity()){
                                    System.out.println("ELE OVERLOAD!");
                                    System.exit(-30);
                                }
                                ele.setPassagernum(ele.getPassagernum()+1);
                                eleMap.put(elename,ele);
                            }
                        }
                        else{
                            System.out.println("PERSON "+id+" GET IN TO THE ELE MORE THAN ONE TIME!");
                            System.exit(-15);
                        }
                } else if (m.group("out") != null) {
                    //if(person.getTo().equals(floor)){
                        if(person.getTotime1()==null){
                            person.setTotime1(m.group("time"));
                            if(!person.getTo().equals(floor)){
                                person.setMiddlefloor(floor);
                            }
                            if(!person.getElename1().equals(elename)){
                                System.out.println("PERSON "+id+" OUT IN DIFFERENT ELE!");
                            }else{
                                Elevator ele = eleMap.get(elename);
                                ele.setPassagernum(ele.getPassagernum()-1);
                                eleMap.put(elename,ele);
                            }
                        }else if(person.getTotime1()!=null&&person.getTotime2()==null){
                            if(person.getTo().equals(floor)){
                                person.setTotime2(m.group("time"));
                            }else{
                                System.out.println(id+"PERSON GET OUT IN A WRONG FLOOR(SECOND)");
                                System.exit(-15);
                            }
                            if(!person.getElename2().equals(elename)){
                                System.out.println("PERSON "+id+" OUT IN DIFFERENT ELE!(SECOND)");
                            }else{
                                Elevator ele = eleMap.get(elename);
                                ele.setPassagernum(ele.getPassagernum()-1);
                                eleMap.put(elename,ele);
                            }
                        }
                        else{
                            System.out.println("PERSON "+id+" GET OUT OF THE ELE MORE THAN ONE TIME!");
                            System.exit(-15);
                        }
                }
            }
            Pattern pattern1 = Pattern.compile(gettime);
            Matcher m1 = pattern1.matcher(infor);
            if(m1.find()){
                time = m1.group("time1");
            }

            //arrive time judge
            Pattern pattern2 = Pattern.compile(arrive);
            Matcher m2 = pattern2.matcher(infor);
            if(m2.find()){
                Double thisarrive = Double.parseDouble(m2.group("arrivetime"));
                String elename = m2.group("elename");
                Elevator ele = eleMap.get(elename);
                String type = ele.getType();
                if(arrivetime.get(elename)==null){
                    arrivetime.put(elename,thisarrive);
                }else{
                    Double lastarrive = arrivetime.get(elename);
                    if(type.equals("A")){
                        if(thisarrive-lastarrive<0.39999999){
                            System.out.println("ARRIVE TIME ERROR!(LESS THAN 0.4S)");
                            System.exit(-16);
                        }
                        arrivetime.put(elename,thisarrive);
                    }else if(type.equals("B")){
                        if(thisarrive-lastarrive<0.49999999){
                            System.out.println("ARRIVE TIME ERROR!(LESS THAN 0.5S)");
                            System.exit(-16);
                        }
                        arrivetime.put(elename,thisarrive);
                    }else if(type.equals("C")){
                        if(thisarrive-lastarrive<0.59999999){
                            System.out.println("ARRIVE TIME ERROR!(LESS THAN 0.6S)");
                            System.exit(-16);
                        }
                        arrivetime.put(elename,thisarrive);
                    }
                }
            }

            // open/close time judge
            Pattern pattern3 = Pattern.compile(open);
            Matcher m3 = pattern3.matcher(infor);
            Double thisopen = -1.0;
            if(m3.find()){
                thisopen = Double.parseDouble(m3.group("opentime"));
                String elename = m3.group("elename");
                opentime.put(elename,thisopen);
            }
            Pattern pattern4 = Pattern.compile(close);
            Matcher m4 = pattern4.matcher(infor);
            Double thisclose = -1.0;
            if(m4.find()){
                thisclose = Double.parseDouble(m4.group("closetime"));
                String elename = m4.group("elename");
                Double lastopen = opentime.get(elename);
                if(thisclose-lastopen<0.39999999){
                    System.out.println("OPEN&CLOSE TIME ERROR!(LESS THAN 0.4S)");
                    System.exit(-16);
                }
            }

        }
    }

    public String getTime() {
        return time;
    }

    public void Check() {
        Iterator it = PersonMap.keySet().iterator();
        while (it.hasNext()) {
            String id = (String) it.next();
            Person person = PersonMap.get(id);
            String intime1 = person.getFromtime1();
            String outtime1 = person.getTotime1();
            String intime2 = person.getFromtime2();
            String outtime2 = person.getTotime2();
            String middlefloor = person.getMiddlefloor();
            Double in = 0.0;
            Double out = 0.0;
            if(intime1!=null&&outtime1!=null){
                in = Double.parseDouble(intime1);
                out = Double.parseDouble(outtime1);
            }
            if(intime1!=null&&outtime1!=null&&(in<out)){

            }else{
                if(intime1==null){
                    System.out.println(id+"PERSON NOT IN TO ELE");
                    System.exit(-10);
                } else if(outtime1==null){
                    System.out.println("PERSON NOT OUT OF ELE");
                    System.exit(-11);
                } else if(in>=out){
                    System.out.println("PERSON OUT BEFORE IN");
                    System.exit(-12);
                }
            }
            if(middlefloor==null){
                return;
            }else if(middlefloor!=null&&intime2!=null&&outtime2!=null){
                in = Double.parseDouble(intime2);
                out = Double.parseDouble(outtime2);
            }
            if(middlefloor!=null&&intime2!=null&&outtime2!=null&&(in<out)){

            }else{
                if(intime2==null){
                    System.out.println(id+"PERSON NOT IN TO ELE(SECOND)");
                    System.exit(-10);
                } else if(outtime2==null){
                    System.out.println("PERSON NOT OUT OF ELE(SECOND)");
                    System.exit(-11);
                } else if(in>=out){
                    System.out.println("PERSON OUT BEFORE IN(SECOND)");
                    System.exit(-12);
                }
            }
        }
    }
}
