package check3;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Check {
    private ArrayList<String> inputlist;

    public Check(ArrayList<String> ainputlist) {
        this.inputlist = ainputlist;
    }

    private String deleteTime(String in) {
        String str = "";
        String delete = "\\[.*\\](.*)";
        Pattern deletea = Pattern.compile(delete);

        for(Matcher delmatcher = deletea.matcher(in); delmatcher.find(); str = delmatcher.group(1)) {
        }

        return str;
    }

    private void CheckArrive(int number, String name) throws IndexOutOfBoundsException {
        int currentNum = 0;
        int lastNum = 0;
        String getNum = "(ARRIVE-([+\\-]?\\d+))";
        String CloseGetNum = "(CLOSE-([+\\-]?\\d+))";
        Pattern close = Pattern.compile(CloseGetNum);
        Pattern a = Pattern.compile(getNum);

        Matcher getNumm;
        for(getNumm = a.matcher(this.deleteTime((String)this.inputlist.get(number))); getNumm.find(); currentNum = Integer.parseInt(getNumm.group(2))) {
        }
        if (currentNum < -3 || currentNum == 0 || currentNum > 20) {
            System.out.println("WRONG ANSWER WITH NONE-EXIST FLOOR WITH ELEVATOR " + name + "!");
            System.exit(-1);
        }

        switch(this.deleteTime((String)this.inputlist.get(number - 1)).charAt(0)) {
            case 'A':
                for(getNumm = a.matcher(this.deleteTime((String)this.inputlist.get(number - 1))); getNumm.find(); lastNum = Integer.parseInt(getNumm.group(2))) {
                }
                if (currentNum == 1) {
                    if (!(lastNum == 2 || lastNum == -1)) {
                        System.out.println("WRONG ANSWER WITH MORE THAN ONE BETWEEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-1);
                    }
                }
                else if (currentNum == -1) {
                    if (!(lastNum == -2 || lastNum == 1)) {
                        System.out.println("WRONG ANSWER WITH MORE THAN ONE BETWEEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-1);
                    }
                }
                else if (!(currentNum == lastNum + 1 | currentNum == lastNum - 1)) {
                    System.out.println("WRONG ANSWER WITH MORE THAN ONE BETWEEN FLOOR WITH ELEVATOR " + name + " !");
                    System.exit(-1);
                } else { ; }
                break;
            case 'C':
                for(getNumm = close.matcher(this.deleteTime((String)this.inputlist.get(number - 1))); getNumm.find(); lastNum = Integer.parseInt(getNumm.group(2))) {
                }

                if (currentNum == 1) {
                    if (!(lastNum == 2 || lastNum == -1)) {
                        System.out.println("WRONG ANSWER WITH MORE THAN ONE BETWEEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-1);
                    }
                }
                else if (currentNum == -1) {
                    if (!(lastNum == -2 || lastNum == 1)) {
                        System.out.println("WRONG ANSWER WITH MORE THAN ONE BETWEEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-1);
                    }
                }
                else if (!(currentNum == lastNum + 1 | currentNum == lastNum - 1)) {
                    System.out.println("WRONG ANSWER WITH MORE THAN ONE BETWEEN FLOOR WITH ELEVATOR " + name + " !");
                    System.exit(-1);
                } else { ; }
                break;
            default:
                System.out.println("WRONG ANSWER IN ARRIVE BEHAVIOR WITH ELEVATOR " + name + " !");
                System.exit(-1);
        }

    }

    private void CheckCloseA(int num, String name) {
        int currentNum = 0;
        int lastNum = 0;
        String getNum = "(CLOSE-([+\\-]?\\d+))";
        Pattern a = Pattern.compile(getNum);

        for(Matcher getNumm = a.matcher(this.deleteTime((String)this.inputlist.get(num))); getNumm.find(); currentNum = Integer.parseInt(getNumm.group(2))) {
        }

        if (currentNum == 0 || (currentNum >= 2 && currentNum <= 14)) {
            System.out.println("WRONG ANSWER IN CLOSE AT TYPE-A NONE-BERTH FLOOR WITH ELEVATOR " + name + "!");
            System.exit(-2);
        }

        switch(this.deleteTime((String)this.inputlist.get(num - 1)).charAt(0)) {
            case 'I':
            case 'O':
                String str = ".*-(\\d+)-([+\\-]?\\d+)";
                Pattern b = Pattern.compile(str);

                for(Matcher strm = b.matcher(this.deleteTime((String)this.inputlist.get(num - 1))); strm.find(); lastNum = Integer.parseInt(strm.group(2))) {
                }

                if (currentNum != lastNum) {
                    System.out.println(currentNum + " " + lastNum);
                    System.out.println("WRONG ANSWER WITH CLOSE AT WRONG FLOOR WITH ELEVATOR " + name + " !");
                    System.exit(-2);
                }
                break;
            case 'o':
                String str1 = "open-([+\\-]?\\d+)";
                Pattern c = Pattern.compile(str1);

                for(Matcher str1m = c.matcher(this.deleteTime((String)this.inputlist.get(num - 1))); str1m.find(); lastNum = Integer.parseInt(str1m.group(1))) {
                }

                if (currentNum != lastNum) {
                    System.out.println("WRONG ANSWER WITH CLOSE AT WRONG FLOOR WITH ELEVATOR " + name + " !");
                    System.exit(-2);
                }
                break;
            default:
                System.out.println("WRONG ANSWER IN CLOSE WITH ELEVATOR " + name + " !");
                System.exit(-2);
        }

    }

    private void CheckCloseB(int num, String name) {
        int currentNum = 0;
        int lastNum = 0;
        String getNum = "(CLOSE-([+\\-]?\\d+))";
        Pattern a = Pattern.compile(getNum);

        for(Matcher getNumm = a.matcher(this.deleteTime((String)this.inputlist.get(num))); getNumm.find(); currentNum = Integer.parseInt(getNumm.group(2))) {
        }

        if (currentNum == 0 || currentNum == -3 || currentNum == 3 || currentNum > 15) {
            System.out.println("WRONG ANSWER IN CLOSE AT TYPE-B NONE-BERTH FLOOR WITH ELEVATOR " + name + "!");
            System.exit(-2);
        }

        switch(this.deleteTime((String)this.inputlist.get(num - 1)).charAt(0)) {
            case 'I':
            case 'O':
                String str = ".*-(\\d+)-([+\\-]?\\d+)";
                Pattern b = Pattern.compile(str);

                for(Matcher strm = b.matcher(this.deleteTime((String)this.inputlist.get(num - 1))); strm.find(); lastNum = Integer.parseInt(strm.group(2))) {
                }

                if (currentNum != lastNum) {
                    System.out.println(currentNum + " " + lastNum);
                    System.out.println("WRONG ANSWER WITH CLOSE AT WRONG FLOOR WITH ELEVATOR " + name + " !");
                    System.exit(-2);
                }
                break;
            case 'o':
                String str1 = "open-([+\\-]?\\d+)";
                Pattern c = Pattern.compile(str1);

                for(Matcher str1m = c.matcher(this.deleteTime((String)this.inputlist.get(num - 1))); str1m.find(); lastNum = Integer.parseInt(str1m.group(1))) {
                }

                if (currentNum != lastNum) {
                    System.out.println("WRONG ANSWER WITH CLOSE AT WRONG FLOOR WITH ELEVATOR " + name + " !");
                    System.exit(-2);
                }
                break;
            default:
                System.out.println("WRONG ANSWER IN CLOSE WITH ELEVATOR " + name + " !");
                System.exit(-2);
        }

    }

    private void CheckCloseC(int num, String name) {
        int currentNum = 0;
        int lastNum = 0;
        String getNum = "(CLOSE-([+\\-]?\\d+))";
        Pattern a = Pattern.compile(getNum);

        for(Matcher getNumm = a.matcher(this.deleteTime((String)this.inputlist.get(num))); getNumm.find(); currentNum = Integer.parseInt(getNumm.group(2))) {
        }

        if (currentNum <= 0 || currentNum % 2 == 0 || currentNum > 15) {
            System.out.println("WRONG ANSWER IN CLOSE AT TYPE-C NONE-BERTH FLOOR WITH ELEVATOR " + name + "!");
            System.exit(-2);
        }

        switch(this.deleteTime((String)this.inputlist.get(num - 1)).charAt(0)) {
            case 'I':
            case 'O':
                String str = ".*-(\\d+)-([+\\-]?\\d+)";
                Pattern b = Pattern.compile(str);

                for(Matcher strm = b.matcher(this.deleteTime((String)this.inputlist.get(num - 1))); strm.find(); lastNum = Integer.parseInt(strm.group(2))) {
                }

                if (currentNum != lastNum) {
                    System.out.println(currentNum + " " + lastNum);
                    System.out.println("WRONG ANSWER WITH CLOSE AT WRONG FLOOR WITH ELEVATOR " + name + " !");
                    System.exit(-2);
                }
                break;
            case 'o':
                String str1 = "open-([+\\-]?\\d+)";
                Pattern c = Pattern.compile(str1);

                for(Matcher str1m = c.matcher(this.deleteTime((String)this.inputlist.get(num - 1))); str1m.find(); lastNum = Integer.parseInt(str1m.group(1))) {
                }

                if (currentNum != lastNum) {
                    System.out.println("WRONG ANSWER WITH CLOSE AT WRONG FLOOR WITH ELEVATOR " + name + " !");
                    System.exit(-2);
                }
                break;
            default:
                System.out.println("WRONG ANSWER IN CLOSE WITH ELEVATOR " + name + " !");
                System.exit(-2);
        }

    }


    private void CheckOpenA(int num, String name) {
        int currentNum = 0;
        int lastNum = 0;
        String getNum = "open-([+\\-]?\\d+)";
        Pattern a = Pattern.compile(getNum);

        for(Matcher getNumm = a.matcher(this.deleteTime((String)this.inputlist.get(num))); getNumm.find(); currentNum = Integer.parseInt(getNumm.group(1))) {
        }
        if (currentNum == 0 || (currentNum >= 2 && currentNum <= 14)) {
            System.out.println("WRONG ANSWER IN OPEN AT TYPE-A NONE-BERTH FLOOR WITH ELEVATOR " + name + "!");
            System.exit(-3);
        }


        if (num == 0) {
            if (currentNum != 1) {
                System.out.println("WRONG START FLOOR WITH ELEVATOR " + name + " !");
                System.exit(-3);
            }
        } else {
            switch(this.deleteTime((String)this.inputlist.get(num - 1)).charAt(0)) {
                case 'A':
                    Pattern str = Pattern.compile("ARRIVE-([+\\-]?\\d+)");

                    for(Matcher strm = str.matcher(this.deleteTime((String)this.inputlist.get(num - 1))); strm.find(); lastNum = Integer.parseInt(strm.group(1))) {
                    }

                    if (currentNum != lastNum) {
                        System.out.println("WRONG ANSWER WITH WRONG OPEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-3);
                    }
                    break;
                case 'C':
                    Pattern str1 = Pattern.compile("CLOSE-([+\\-]?\\d+)");

                    for(Matcher str1m = str1.matcher(deleteTime(inputlist.get(num - 1))); str1m.find(); lastNum = Integer.parseInt(str1m.group(1))) {
                    }

                    if (currentNum != lastNum) {
                        System.out.println("WRONG ANSWER WITH WRONG OPEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-3);
                    }
                    break;
                default:
                    System.out.println("WRONG ANSWER IN OPEN WITH ELEVATOR " + name + " !");
                    System.exit(-3);
            }
        }

    }

    private void CheckOpenB(int num, String name) {
        int currentNum = 0;
        int lastNum = 0;
        String getNum = "open-([+\\-]?\\d+)";
        Pattern a = Pattern.compile(getNum);

        for(Matcher getNumm = a.matcher(this.deleteTime((String)this.inputlist.get(num))); getNumm.find(); currentNum = Integer.parseInt(getNumm.group(1))) {
        }
        if (currentNum == 0 || currentNum == -3 || currentNum == 3 || currentNum > 15) {
            System.out.println("WRONG ANSWER IN OPEN AT TYPE-B NONE-BERTH FLOOR WITH ELEVATOR " + name + "!");
            System.exit(-3);
        }


        if (num == 0) {
            if (currentNum != 1) {
                System.out.println("WRONG START FLOOR WITH ELEVATOR " + name + " !");
                System.exit(-3);
            }
        } else {
            switch(this.deleteTime((String)this.inputlist.get(num - 1)).charAt(0)) {
                case 'A':
                    Pattern str = Pattern.compile("ARRIVE-([+\\-]?\\d+)");

                    for(Matcher strm = str.matcher(this.deleteTime((String)this.inputlist.get(num - 1))); strm.find(); lastNum = Integer.parseInt(strm.group(1))) {
                    }

                    if (currentNum != lastNum) {
                        System.out.println("WRONG ANSWER WITH WRONG OPEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-3);
                    }
                    break;
                case 'C':
                    Pattern str1 = Pattern.compile("CLOSE-([+\\-]?\\d+)");

                    for(Matcher str1m = str1.matcher(deleteTime(inputlist.get(num - 1))); str1m.find(); lastNum = Integer.parseInt(str1m.group(1))) {
                    }

                    if (currentNum != lastNum) {
                        System.out.println("WRONG ANSWER WITH WRONG OPEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-3);
                    }
                    break;
                default:
                    System.out.println("WRONG ANSWER IN OPEN WITH ELEVATOR " + name + " !");
                    System.exit(-3);
            }
        }

    }

    private void CheckOpenC(int num, String name) {
        int currentNum = 0;
        int lastNum = 0;
        String getNum = "open-([+\\-]?\\d+)";
        Pattern a = Pattern.compile(getNum);

        for(Matcher getNumm = a.matcher(this.deleteTime((String)this.inputlist.get(num))); getNumm.find(); currentNum = Integer.parseInt(getNumm.group(1))) {
        }
        if (currentNum <= 0 || currentNum % 2 == 0 || currentNum > 15) {
            System.out.println("WRONG ANSWER IN OPEN AT TYPE-C NONE-BERTH FLOOR WITH ELEVATOR " + name + "!");
            System.exit(-3);
        }


        if (num == 0) {
            if (currentNum != 1) {
                System.out.println("WRONG START FLOOR WITH ELEVATOR " + name + " !");
                System.exit(-3);
            }
        } else {
            switch(this.deleteTime((String)this.inputlist.get(num - 1)).charAt(0)) {
                case 'A':
                    Pattern str = Pattern.compile("ARRIVE-([+\\-]?\\d+)");

                    for(Matcher strm = str.matcher(this.deleteTime((String)this.inputlist.get(num - 1))); strm.find(); lastNum = Integer.parseInt(strm.group(1))) {
                    }

                    if (currentNum != lastNum) {
                        System.out.println("WRONG ANSWER WITH WRONG OPEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-3);
                    }
                    break;
                case 'C':
                    Pattern str1 = Pattern.compile("CLOSE-([+\\-]?\\d+)");

                    for(Matcher str1m = str1.matcher(deleteTime(inputlist.get(num - 1))); str1m.find(); lastNum = Integer.parseInt(str1m.group(1))) {
                    }

                    if (currentNum != lastNum) {
                        System.out.println("WRONG ANSWER WITH WRONG OPEN FLOOR WITH ELEVATOR " + name + " !");
                        System.exit(-3);
                    }
                    break;
                default:
                    System.out.println("WRONG ANSWER IN OPEN WITH ELEVATOR " + name + " !");
                    System.exit(-3);
            }
        }

    }

    private void Checkin(int num) {
    }

    private void Checkout(int num) {
    }

    public void BehaviorCheckA(String name) {
        for(int i = 0; i < this.inputlist.size(); ++i) {
            String temp = this.deleteTime((String)this.inputlist.get(i));
            switch(temp.charAt(0)) {
                case 'A':
                    try {
                        this.CheckArrive(i, name);
                    } catch (IndexOutOfBoundsException var5) {

                    }
                    break;
                case 'C':
                    try {
                        this.CheckCloseA(i, name);
                    } catch (IndexOutOfBoundsException var4) {
                        System.out.println("WRONG ANSWER IN CLOSE WITH ELEVATOR " + name + " !");
                        System.exit(-2);
                    }
                    break;
                case 'I':
                    this.Checkin(i);
                    break;
                case 'O':
                    this.Checkout(i);
                    break;
                case 'o':
                    this.CheckOpenA(i, name);
                    break;
                default:
                    System.out.println("WRONG FORMAT OUTPUT WITH ELEVATOR " + name + " !");
                    System.exit(-100);
            }
        }
    }

    public void BehaviorCheckB(String name) {
        for(int i = 0; i < this.inputlist.size(); ++i) {
            String temp = this.deleteTime((String)this.inputlist.get(i));
            switch(temp.charAt(0)) {
                case 'A':
                    try {
                        this.CheckArrive(i, name);
                    } catch (IndexOutOfBoundsException var5) {

                    }
                    break;
                case 'C':
                    try {
                        this.CheckCloseB(i, name);
                    } catch (IndexOutOfBoundsException var4) {
                        System.out.println("WRONG ANSWER IN CLOSE WITH ELEVATOR " + name + " !");
                        System.exit(-2);
                    }
                    break;
                case 'I':
                    this.Checkin(i);
                    break;
                case 'O':
                    this.Checkout(i);
                    break;
                case 'o':
                    this.CheckOpenB(i, name);
                    break;
                default:
                    System.out.println("WRONG FORMAT OUTPUT WITH ELEVATOR " + name + " !");
                    System.exit(-101);
            }
        }
    }

    public void BehaviorCheckC(String name) {
        for(int i = 0; i < this.inputlist.size(); ++i) {
            String temp = this.deleteTime((String)this.inputlist.get(i));
            switch(temp.charAt(0)) {
                case 'A':
                    try {
                        this.CheckArrive(i, name);
                    } catch (IndexOutOfBoundsException var5) {

                    }
                    break;
                case 'C':
                    try {
                        this.CheckCloseC(i, name);
                    } catch (IndexOutOfBoundsException var4) {
                        System.out.println("WRONG ANSWER IN CLOSE WITH ELEVATOR " + name + " !");
                        System.exit(-2);
                    }
                    break;
                case 'I':
                    this.Checkin(i);
                    break;
                case 'O':
                    this.Checkout(i);
                    break;
                case 'o':
                    this.CheckOpenC(i, name);
                    break;
                default:
                    System.out.println("WRONG FORMAT OUTPUT WITH ELEVATOR " + name + " !");
                    System.exit(-102);
            }
        }
    }


}