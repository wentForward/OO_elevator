package check3;

class Elevator {
    private String elename = "";
    private int passagernum = 0;
    private int capacity;
    private String type = "";


    public Elevator(String elename,String type){
        this.type = type;
        this.elename = elename;
        switch (type){
            case "A":
                capacity = 6;
                break;
            case "B":
                capacity = 8;
                break;
            case "C":
                capacity = 7;
                break;
        }
    }

    public int getPassagernum() {
        return passagernum;
    }

    public void setPassagernum(int passagernum) {
        this.passagernum = passagernum;
    }

    public String getElename() {
        return elename;
    }

    public int getCapacity() {
        return capacity;
    }

    public String getType() {
        return type;
    }
}
