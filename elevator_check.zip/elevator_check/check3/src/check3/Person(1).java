package check3;

class Person {
    private String id;
    private String from;
    private String to;
    private String fromtime1=null;
    private String totime1=null;
    private String fromtime2=null;
    private String totime2=null;
    private String elename1 = null;
    private String elename2 = null;
    private String middlefloor = null;

    public Person(String id,String from,String to){
        this.id = id;
        this.from = from;
        this.to = to;
    }

    public void setFromtime1(String from){
        fromtime1 = from;
    }
    public  void setTotime1(String to){
        totime1 = to;
    }

    public String getFromtime1() {
        return fromtime1;
    }

    public String getTotime1() {
        return totime1;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getElename1() {
        return elename1;
    }

    public void setElename1(String elename) {
        this.elename1 = elename;
    }

    public String getMiddlefloor() {
        return middlefloor;
    }

    public void setMiddlefloor(String middlefloor) {
        this.middlefloor = middlefloor;
    }

    public String getFromtime2() {
        return fromtime2;
    }

    public void setFromtime2(String fromtime2) {
        this.fromtime2 = fromtime2;
    }

    public String getTotime2() {
        return totime2;
    }

    public void setTotime2(String totime2) {
        this.totime2 = totime2;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getElename2() {
        return elename2;
    }

    public void setElename2(String elename2) {
        this.elename2 = elename2;
    }
}
